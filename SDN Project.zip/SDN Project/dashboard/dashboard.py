import streamlit as st
import json, time, os
import pandas as pd
import plotly.express as px

# =============================================
# STREAMLIT CONFIG
# =============================================
st.set_page_config(
    page_title="SDN Load Balancer Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🌐 SDN Load Balancer — Monitoring Dashboard")

# Auto-refresh every 1 second
st_autorefresh = st.experimental_rerun


# =============================================
# FILE PATHS
# =============================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(BASE_DIR, ".."))

METRICS_PATH = os.path.join(ROOT_DIR, "metrics.json")
LOG_PATH = os.path.join(ROOT_DIR, "lb.log")
ADMIN_CMD_PATH = os.path.join(ROOT_DIR, "load_balancer", "admin_commands.json")
LB_MODE_PATH = os.path.join(ROOT_DIR, "load_balancer", "lb_mode.txt")


# =============================================
# FUNCTIONS
# =============================================
def load_metrics():
    try:
        if os.path.exists(METRICS_PATH):
            with open(METRICS_PATH) as f:
                return json.load(f)
    except:
        pass
    return {}


def load_logs():
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, "r", errors="ignore") as f:
        return f.readlines()[-40:]


def save_admin_command(command, value=None):
    cmd = {"command": command, "value": value}
    with open(ADMIN_CMD_PATH, "w") as f:
        json.dump(cmd, f, indent=2)


def load_lb_mode():
    if os.path.exists(LB_MODE_PATH):
        return open(LB_MODE_PATH).read().strip()
    return "weighted"


def set_lb_mode(mode):
    with open(LB_MODE_PATH, "w") as f:
        f.write(mode)


# =============================================
# SIDEBAR CONTROLS
# =============================================
st.sidebar.header("⚙️ Admin Controls")

current_mode = load_lb_mode()
st.sidebar.write(f"### Current LB Mode: `{current_mode}`")

selected_mode = st.sidebar.selectbox(
    "Select Load Balancing Algorithm",
    ["weighted", "round_robin", "least_conn", "random"]
)

if st.sidebar.button("Apply LB Mode"):
    set_lb_mode(selected_mode)
    st.sidebar.success(f"Updated mode to: {selected_mode}")
    st.experimental_rerun()

st.sidebar.markdown("---")

if st.sidebar.button("➕ Add Server"):
    save_admin_command("add_server")
    st.sidebar.success("Add server command sent.")
    st.experimental_rerun()

if st.sidebar.button("➖ Remove Server"):
    save_admin_command("remove_server")
    st.sidebar.success("Remove server command sent.")
    st.experimental_rerun()

if st.sidebar.button("🔄 Restart All Servers"):
    save_admin_command("restart_all")
    st.sidebar.success("Restart all servers command sent.")
    st.experimental_rerun()

if st.sidebar.button("🧹 Clear Metrics"):
    save_admin_command("clear_metrics")
    st.sidebar.success("Clear metrics command sent.")
    st.experimental_rerun()

st.sidebar.markdown("---")
if st.sidebar.button("🔁 Refresh Now"):
    st.experimental_rerun()


# =============================================
# MAIN DASHBOARD
# =============================================
data = load_metrics()

if not data or "timestamps" not in data:
    st.info("Waiting for metrics...")
    st.stop()

server_list = data.get("servers", [])
req_count = data.get("req_count", {})
throughput = data.get("throughput", {})

df = pd.DataFrame({
    "timestamp": data["timestamps"],
    "latency": data["latency"],
    "server": data["server_used"]
})

# =============================================
# METRICS TOP ROW
# =============================================
col1, col2, col3, col4 = st.columns(4)

col1.metric("Active Servers", len(server_list))
col2.metric("Total Requests", sum(req_count.values()))
col3.metric("Avg Latency (s)", round(df["latency"].mean(), 3) if len(df) else 0)
col4.metric("Max Throughput (req/s)", max(throughput.values()) if throughput else 0)

st.markdown("---")

# =============================================
# GRAPHS
# =============================================
colA, colB = st.columns(2)

# Latency graph
if len(df) > 0:
    figA = px.line(df, x="timestamp", y="latency",
                   title="Latency Over Time", markers=True)
    colA.plotly_chart(figA, use_container_width=True)

# Request count bar graph
req_df = pd.DataFrame({
    "server": list(req_count.keys()),
    "count": list(req_count.values())
})
figB = px.bar(req_df, x="server", y="count",
              title="Request Count per Server")
colB.plotly_chart(figB, use_container_width=True)

st.markdown("---")

# =============================================
# PIE + SERVER TABLE
# =============================================
colC, colD = st.columns(2)

if len(df) > 0:
    figC = px.pie(df, names="server", title="Traffic Distribution")
    colC.plotly_chart(figC, use_container_width=True)

health_df = pd.DataFrame({
    "Server URL": server_list,
    "Requests": [req_count.get(s, 0) for s in server_list],
    "Throughput": [throughput.get(s, 0) for s in server_list]
})
colD.subheader("🟢 Server Statistics")
colD.dataframe(health_df, use_container_width=True)

st.markdown("---")

# =============================================
# LOGS
# =============================================
st.subheader("📜 Live Logs")

logs = load_logs()
if logs:
    for entry in logs:
        st.code(entry.strip())
else:
    st.code("No logs yet.")


# =============================================
# AUTO REFRESH
# =============================================
time.sleep(1)
st.experimental_rerun()
