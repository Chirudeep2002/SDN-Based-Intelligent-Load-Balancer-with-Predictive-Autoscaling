import requests, time

for i in range(500):
    try:
        r = requests.get("http://127.0.0.1:8000", timeout=2)
        print("OK:", r.json())
    except Exception as e:
        print("ERROR:", e)
    time.sleep(0.5)
