import time, os, json, random
from predictive_scaler import predictive_scale
from registry import registry
from metrics_manager import log_event

ADMIN_CMD_PATH = "admin_commands.json"


# ======================================================
# Helper — Execute Admin Commands for Autoscaling
# ======================================================
def check_admin_commands():
    if not os.path.exists(ADMIN_CMD_PATH):
        return

    try:
        with open(ADMIN_CMD_PATH) as f:
            cmd = json.load(f)
    except:
        return

    if not cmd:
        return

    command = cmd.get("command")
    value = cmd.get("value")

    # ======================================================
    # MANUAL: ADD SERVER
    # ======================================================
    if command == "add_server":
        port = random.randint(6000, 7000)
        url = f"http://127.0.0.1:{port}"
        if url not in registry:
            registry[url] = {"weight": 1, "status": "alive"}
            log_event(f"[ADMIN-AUTOSCALE] Manually added server: {url}")

    # ======================================================
    # MANUAL: REMOVE SERVER
    # ======================================================
    elif command == "remove_server":
        if len(registry) > 1:
            victim = random.choice(list(registry.keys()))
            del registry[victim]
            log_event(f"[ADMIN-AUTOSCALE] Manually removed server: {victim}")

    # ======================================================
    # MANUAL: RESTART ALL
    # ======================================================
    elif command == "restart_all":
        for srv in registry:
            registry[srv]["status"] = "alive"
        log_event("[ADMIN-AUTOSCALE] All servers restarted (simulated).")

    # ======================================================
    # MANUAL: CLEAR METRICS
    # ======================================================
    elif command == "clear_metrics":
        log_event("[ADMIN-AUTOSCALE] Metrics clear requested.")

    # Clear command file (avoid repeat execution)
    open(ADMIN_CMD_PATH, "w").write("")


# ======================================================
# MAIN AUTOSCALE LOOP
# ======================================================
log_event("[AUTOSCALE] Autoscaler started.")

while True:

    # 1. Manual commands from dashboard
    check_admin_commands()

    # 2. Predictive autoscaling (latency-based)
    predictive_scale()

    # 3. Sleep before next cycle
    time.sleep(4)
