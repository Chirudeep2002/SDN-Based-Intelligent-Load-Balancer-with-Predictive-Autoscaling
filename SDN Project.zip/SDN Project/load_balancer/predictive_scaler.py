from metrics_manager import metrics, log_event
from registry import registry
import random

def predictive_scale():
    if len(metrics["latency"]) < 12:
        return

    last = metrics["latency"][-12:]
    avg = sum(last) / len(last)

    if avg > 0.9:
        port = random.randint(6000, 7000)
        url = f"http://127.0.0.1:{port}"
        registry[url] = {"weight": 1, "status": "alive"}
        log_event(f"[AUTOSCALE] Added server {url}")

    elif avg < 0.2 and len(registry) > 1:
        url = random.choice(list(registry.keys()))
        del registry[url]
        log_event(f"[AUTOSCALE] Removed server {url}")
