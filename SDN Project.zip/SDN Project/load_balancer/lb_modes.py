import random
from itertools import cycle
from registry import registry
from cpu_weight_manager import calc_cpu_weight_list
from metrics_manager import metrics

def rr_cycle():
    return cycle(list(registry.keys()))

def random_choice():
    return random.choice(list(registry.keys()))

def least_conn():
    req = metrics["req_count"]
    if req:
        return min(req, key=req.get)
    return random.choice(list(registry.keys()))

def weighted_cycle():
    return cycle(calc_cpu_weight_list())
