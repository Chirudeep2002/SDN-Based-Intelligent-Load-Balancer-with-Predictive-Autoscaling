import random

def simulate_resources():
    return {
        "cpu": random.randint(10, 95),
        "memory": random.randint(10, 95),
    }
