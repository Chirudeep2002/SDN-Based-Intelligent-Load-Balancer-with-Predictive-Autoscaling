import requests, time
from registry import registry
from metrics_manager import log_event

def check_health():
    for server in registry:
        try:
            start = time.time()
            requests.get(server + "/heartbeat", timeout=1)
            latency = time.time() - start

            if latency > 1.0:
                registry[server]["status"] = "degraded"
            else:
                registry[server]["status"] = "alive"

        except:
            registry[server]["status"] = "dead"

def auto_restart_dead():
    for server, info in registry.items():
        if info["status"] == "dead":
            log_event(f"Restarting {server} (simulated reboot)")
            time.sleep(1)
            info["status"] = "alive"
