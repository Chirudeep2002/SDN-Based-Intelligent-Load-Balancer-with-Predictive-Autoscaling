import time, os, json, requests, random
from flask import Flask, jsonify

from registry import registry
from lb_modes import rr_cycle, random_choice, least_conn, weighted_cycle
from metrics_manager import update_metrics, log_event, save, metrics
from health_manager import check_health, auto_restart_dead

# ======================================================
# FILE PATHS
# ======================================================
ADMIN_CMD_PATH = "admin_commands.json"
LB_MODE_PATH = "lb_mode.txt"
METRICS_PATH = "../metrics.json"

app = Flask("SDN-LB")


# ======================================================
# LOAD BALANCER MODE MANAGEMENT
# ======================================================

def get_lb_mode():
    """Reads the current LB mode from lb_mode.txt."""
    if os.path.exists(LB_MODE_PATH):
        return open(LB_MODE_PATH).read().strip()
    return "weighted"


def build_cycle(mode):
    """Builds the generator based on chosen mode."""
    if mode == "round_robin":
        return rr_cycle()
    elif mode == "least_conn":
        return rr_cycle()
    elif mode == "random":
        return rr_cycle()
    elif mode == "weighted":
        return weighted_cycle()
    return weighted_cycle()


LB_MODE = get_lb_mode()
cycle_gen = build_cycle(LB_MODE)

log_event(f"[LB] Load Balancer started in '{LB_MODE}' mode.")
log_event(f"[LB] Load Balancer running on port 8000")


# ======================================================
# ADMIN COMMANDS
# ======================================================

def check_admin_command():
    """Reads admin_commands.json and executes admin actions."""
    if not os.path.exists(ADMIN_CMD_PATH):
        return

    try:
        with open(ADMIN_CMD_PATH) as f:
            cmd = json.load(f)
    except:
        return

    if not cmd:
        return

    command = cmd.get("command")

    # ADD SERVER
    if command == "add_server":
        port = random.randint(6000, 7000)
        url = f"http://127.0.0.1:{port}"
        registry[url] = {"weight": 1, "status": "alive"}
        log_event(f"[ADMIN] Added server: {url}")

    # REMOVE SERVER
    elif command == "remove_server":
        if len(registry) > 1:
            victim = random.choice(list(registry.keys()))
            del registry[victim]
            log_event(f"[ADMIN] Removed server: {victim}")

    # RESTART ALL
    elif command == "restart_all":
        for srv in registry:
            registry[srv]["status"] = "alive"
        log_event("[ADMIN] Restarted all servers")

    # CLEAR METRICS
    elif command == "clear_metrics":
        with open(METRICS_PATH, "w") as f:
            json.dump({
                "timestamps": [],
                "latency": [],
                "server_used": [],
                "req_count": {},
                "throughput": {},
                "servers": []
            }, f, indent=2)
        log_event("[ADMIN] Metrics cleared")

    # Clear file to avoid re-trigger
    open(ADMIN_CMD_PATH, "w").write("")


# ======================================================
# MAIN LOAD BALANCER ROUTE
# ======================================================

@app.route("/")
def route_request():
    global LB_MODE, cycle_gen

    # 1. Health check + auto revival
    check_health()
    auto_restart_dead()

    # 2. Admin commands
    check_admin_command()

    # 3. Mode refresh
    new_mode = get_lb_mode()
    if new_mode != LB_MODE:
        LB_MODE = new_mode
        cycle_gen = build_cycle(LB_MODE)
        log_event(f"[LB] Mode updated to: {LB_MODE}")

    # 4. Select server
    for _ in range(len(registry) * 2):

        if LB_MODE == "random":
            server = random_choice()

        elif LB_MODE == "least_conn":
            server = least_conn()

        elif LB_MODE == "round_robin":
            try:
                server = next(cycle_gen)
            except StopIteration:
                cycle_gen = rr_cycle()
                server = next(cycle_gen)

        elif LB_MODE == "weighted":
            try:
                server = next(cycle_gen)
            except StopIteration:
                cycle_gen = weighted_cycle()
                server = next(cycle_gen)

        # Skip dead servers
        if registry[server]["status"] != "alive":
            continue

        # 5. Send request to backend
        try:
            start = time.time()
            resp = requests.get(server, timeout=2)
            latency = round(time.time() - start, 3)

            # Update metrics
            update_metrics(server, latency)

            # Log request (NEW)
            log_event(f"[LB] Request -> {server}, latency={latency}s")

            # Save active server list
            metrics["servers"] = list(registry.keys())
            save()

            return jsonify({
                "server": server,
                "latency": latency,
                "response": resp.json()
            })

        except Exception as e:
            registry[server]["status"] = "dead"
            log_event(f"[LB] Server failed: {server} | Error: {str(e)}")
            continue

    return jsonify({"error": "No servers alive"})


# ======================================================
# START FLASK APP
# ======================================================
if __name__ == "__main__":
    app.run(port=8000)
